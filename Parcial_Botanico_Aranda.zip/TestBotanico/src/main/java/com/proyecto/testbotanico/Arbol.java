
package com.proyecto.testbotanico;


public class Arbol extends Planta implements Podar {
    
    private int alturaMaxima;
    
    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }
    
    

    @Override
    public void podar() {
        System.out.println("Soy un Arbol y me estan podando");; 
    }
    
    @Override 
    public String toString(){
        return "//Arbol: " + nombre + " //Ubicacion: " + ubicacion + " //Clima: " + clima + " //Altura Maxima: " + alturaMaxima;
    }
    
}
