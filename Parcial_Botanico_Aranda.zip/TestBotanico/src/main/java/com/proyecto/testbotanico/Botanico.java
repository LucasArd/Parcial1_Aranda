package com.proyecto.testbotanico;

import java.util.List;
import java.util.ArrayList;

public class Botanico {

    private List<Planta> plantas;

    public Botanico() {
        plantas = new ArrayList<>();
    }

    public boolean plantaRepetida(Planta p) {
        if (plantas.contains(p)) {
            throw new PlantaRepetidaException();
        }

        return false;
    }

    public void agregarPlanta(Planta p) {
        if (p == null) {
            throw new NullPointerException("NULL");
        }
        if (!plantaRepetida(p)) {
            plantas.add(p);
            System.out.println("Planta agregada con exito");
        }
    }

    public void mostrarPlantas() {
        for (Planta planta : plantas){
            System.out.println(planta.toString());
        }
    }

    public void podarPlantas() {
        for (Planta p : plantas){
            if(p instanceof Podar plant){
                plant.podar();
            }
            else{
                System.out.println("Esta planta no es podable");
            }
            
        }

    }

}
