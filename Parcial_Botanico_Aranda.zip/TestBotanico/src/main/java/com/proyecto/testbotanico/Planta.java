
package com.proyecto.testbotanico;

import java.util.Objects;

public abstract class Planta {
    
    protected String nombre;
    protected String ubicacion;
    protected String clima;
    
    public Planta(String nombre, String ubicacion, String clima){
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
        
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(o instanceof Planta other){
            return other.nombre.equals(this.nombre) && other.ubicacion.equals(this.ubicacion);
        }
        return false;
            
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre,ubicacion);
    }
}
