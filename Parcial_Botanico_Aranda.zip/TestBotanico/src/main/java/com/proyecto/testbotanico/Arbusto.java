
package com.proyecto.testbotanico;


public class Arbusto extends Planta implements Podar {
    
    private static final int DENSIDAD_MAXIMA = 10;
    private static final int DENSIDAD_MINIMA = 1;
    private int densidad;

    public Arbusto(String nombre, String ubicacion, String clima, int densidad) {
        super(nombre, ubicacion, clima);
        if(validarDensidad(densidad)){
            this.densidad = densidad;
        }
        
    }
    
    private static boolean validarDensidad(int densidad){
        if(densidad < DENSIDAD_MINIMA || densidad > DENSIDAD_MAXIMA ){
            throw new IllegalArgumentException("Densidad invalida");
        }
        return true;
    }

    @Override
    public void podar() {
        System.out.println("Soy un Arbusto y me estan podando");; 
    }
    
    @Override 
    public String toString(){
        return "//Arbusto: " + nombre + " //Ubicacion: " + ubicacion + " //Clima: " + clima + " //Densidad: " + densidad;
    }
    
    
}
