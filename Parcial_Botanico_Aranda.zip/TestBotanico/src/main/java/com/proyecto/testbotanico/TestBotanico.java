package com.proyecto.testbotanico;

import java.util.Scanner;

public class TestBotanico {

    public static void main(String[] args) {
        Botanico botanico = new Botanico();
        Scanner input = new Scanner(System.in);
        int numero;
        System.out.print(" Opcion 1 para probar sin errores "
                + "\n Opcion 2 para probar error de planta repetida "
                + "\n Opcion 3 para probar error NULL "
                + "\n Opcion 4 para probar error Densidad de Arbusto Invalida"
                + "\n Ingrese su opcion: ");
        numero = input.nextInt();
        System.out.println("Ingresaste el numero: " + numero);

        switch (numero) {
            case 1:
                try {
                    ingresarPlanta(botanico);
                } catch (NullPointerException e) {
                    System.out.println("Error: " + e.getMessage());
                } catch (PlantaRepetidaException ex) {
                    System.out.println(ex.getMessage());
                } catch (Exception exc) {
                    System.out.println("Ocurrio un error inesperado, reintentar..." + exc.getMessage());
                }
                break;
            case 2:
                try {
                    ingresarPlanta(botanico);
                    botanico.agregarPlanta(new Arbol("Roble","Zona norte","Frio", 9));
                } catch (NullPointerException e) {
                    System.out.println("Error: " + e.getMessage());
                } catch (PlantaRepetidaException ex) {
                    System.out.println(ex.getMessage());
                } catch (Exception exc) {
                    System.out.println("Ocurrio un error inesperado, reintentar..." + exc.getMessage());
                }
                break;
            case 3:
                try {
                    ingresarPlanta(botanico);
                    botanico.agregarPlanta(null);
                } catch (NullPointerException e) {
                    System.out.println("Error: " + e.getMessage());
                } catch (PlantaRepetidaException ex) {
                    System.out.println(ex.getMessage());
                } catch (Exception exc) {
                    System.out.println("Ocurrio un error inesperado, reintentar..." + exc.getMessage());
                }
                break;
            case 4:
                try {
                    ingresarPlanta(botanico);
                    botanico.agregarPlanta(new Arbusto("Arbustito", "Pabellon2", "Frio", 11));
                } catch (NullPointerException e) {
                    System.out.println("Error: " + e.getMessage());
                } catch (PlantaRepetidaException ex) {
                    System.out.println(ex.getMessage());
                } catch (Exception exc) {
                    System.out.println("Ocurrio un error inesperado, reintentar..." + exc.getMessage());
                }
                break;
                
        
        }
        botanico.mostrarPlantas();
        botanico.podarPlantas();

    }

    public static void ingresarPlanta(Botanico botanico) {
        try {
            botanico.agregarPlanta(new Arbol("Banano", "Pabellon1", "Calido", 8));
            botanico.agregarPlanta(new Arbol("Roble", "Zona norte", "Calido", 2));
            botanico.agregarPlanta(new Arbusto("Arbustito", "Pabellon2", "Frio", 5));
            botanico.agregarPlanta(new Flor("Margarita", "Pabellon4", "Calido", TempFlorecimiento.VERANO));

        } catch (NullPointerException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (PlantaRepetidaException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception exc) {
            System.out.println("Ocurrio un error inesperado, reintentar..." + exc.getMessage());
        }
    }
}
