
package com.proyecto.testbotanico;


public class Flor extends Planta  {
    
    private TempFlorecimiento tempFlorecimiento;

    public Flor(String nombre, String ubicacion, String clima, TempFlorecimiento tempFlorecimiento) {
        super(nombre, ubicacion, clima);
        this.tempFlorecimiento = tempFlorecimiento;
    }
    
    
     
    @Override 
    public String toString(){
        return "//Flor: " + nombre + " //Ubicacion: " + ubicacion + " //Clima: " + clima + " //Temporada de florecimiento: " + tempFlorecimiento ;
    }
}
