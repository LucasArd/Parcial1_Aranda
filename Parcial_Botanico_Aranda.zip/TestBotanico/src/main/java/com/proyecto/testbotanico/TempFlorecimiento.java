
package com.proyecto.testbotanico;


public enum TempFlorecimiento {
    
    VERANO,
    PRIMAVERA,
    OTONIO,
    INVIERNO;
    
}
