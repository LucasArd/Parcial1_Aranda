
package com.proyecto.testbotanico;


public class PlantaRepetidaException extends RuntimeException {
    
    private static final String MESSAGE = "Planta ya ingresada al botanico, verifique datos";
    
    public PlantaRepetidaException(){
        super(MESSAGE);
    }
}
