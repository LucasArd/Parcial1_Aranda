
package com.proyecto.testbotanico;


public interface Podar {
    
    public void podar();
}
